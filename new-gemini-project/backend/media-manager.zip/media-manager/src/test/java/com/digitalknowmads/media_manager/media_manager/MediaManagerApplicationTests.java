package com.digitalknowmads.media_manager.media_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
