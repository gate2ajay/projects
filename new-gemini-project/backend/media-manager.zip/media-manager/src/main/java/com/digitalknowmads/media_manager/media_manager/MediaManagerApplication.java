package com.digitalknowmads.media_manager.media_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediaManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaManagerApplication.class, args);
	}

}
